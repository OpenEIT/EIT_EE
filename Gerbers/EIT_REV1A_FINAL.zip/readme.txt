board stackup


1. top layer
2. inner layer pwr
3. inner layer gnd
16. bottom layer


TOP SIDE  *.GTL
inner layer 2  *.G2L
inner layer 3  *.G3L
BOTTOM SIDE  *.GBL
silkscreen top side  *.GTO
solder stop mask top *.GTS
solder stop mask bottom *.GBS
cream frame top  *.GTC
board outline *.GKO
excellent drill file *.drd
component placement list top	  *.mnt
component placement list bottom *.mnb

